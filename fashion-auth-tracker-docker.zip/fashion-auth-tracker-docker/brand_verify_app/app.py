from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # placeholder auth logic
        return redirect(url_for('register_brand'))
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        # placeholder signup logic
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/register_brand', methods=['GET', 'POST'])
def register_brand():
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description', '')
        # placeholder store logic
        return redirect(url_for('verify_brand'))
    return render_template('register_brand.html')

@app.route('/verify_brand', methods=['GET', 'POST'])
def verify_brand():
    if request.method == 'POST':
        brand_name = request.form.get('brand_name')
        if not brand_name:
            return "Brand name missing", 400
        return render_template('verify_result.html', brand_name=brand_name, verified=True)
    return render_template('verify_brand.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
