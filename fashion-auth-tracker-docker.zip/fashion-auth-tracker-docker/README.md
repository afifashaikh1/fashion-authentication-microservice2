Fashion Auth Tracker - Docker-ready project

How to run locally with Docker:
1. Build and run:
   docker-compose up --build

2. Open in browser:
   http://localhost:5000/login

Project structure:
- brand_verify_app/
  - app.py
  - templates/
  - static/
- Dockerfile
- docker-compose.yml
- requirements.txt
